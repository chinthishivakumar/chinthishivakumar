import './header.css'

//import { Dayjs } from 'dayjs';
import { DemoContainer } from '@mui/x-date-pickers/internals/demo';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import Button from '@mui/material/Button';

function Header(){
    return(
<>
<div className="backgroundimage">
    <div className="Container">
        
    <ul>
        <li><a href="">Home</a></li>
        <li><a href="">Flights</a></li>
        <li><a href="">Hotels</a></li>
        <li><a href="">About</a></li>
        <li><a href="">Login</a></li>
        <li><a href="">Sign Up</a></li>
    </ul>
    
</div>
<div></div>
 <div className='navbar_main1'>
            <div className='navbar_item'><span className='navbar'>City, Property name or Location</span></div>
               <div className='navbar_item'><LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DatePicker']}>
        <DatePicker label="Check-in" />
      </DemoContainer>
    </LocalizationProvider>
  
   
</div>
<div className='navbar_item'><LocalizationProvider dateAdapter={AdapterDayjs}>
      <DemoContainer components={['DatePicker']}>
        <DatePicker label="Check-out" />
      </DemoContainer>
    </LocalizationProvider></div>
    <div className='navbar_item'><Button  variant="text"><span >SEARCH</span></Button></div>
    </div>

</div>


</>


    )
}
export default Header