import './hotelcard.css'
function Hotel(){
   
       
    return(
<div className='main'>
<div className='container_mainitems'>
<div className='container_mainitem'>
     <div  ><span className='listitemmain'>Select Filters</span></div>
         <div className='listitemsbox'>
            <div><span className='listitemheader'>Star Category</span></div>
         <div><ul><li><input type="checkbox" />5 Star</li></ul></div></div>
         <div><div><span className='listitemheader' >Themes</span></div>
         <div><ul><li><input type="checkbox" />Business</li><li><input type="checkbox" />Trident Group</li>
         </ul></div></div>
         <div><div><span className='listitemheader'>User Rating</span></div>
         <div><ul><li><input type="checkbox" />Excellent: 4.2+</li><li><input type="checkbox" />Very Good: 3.5+</li><li><input type="checkbox" />Hotel</li></ul></div></div>
        
         </div>
         <div>

    
    

    <div className='container_main' >
        
        <div className="container_item image"><img src="src\assets\37cd2e08453346ed17b3be7e15fdc67b.webp" alt="" /></div>
        <div className="container_item ">
            <div className='margin'>
            <div><span><p className='hotel_title'>Trident Nariman Point</p></span></div>
            <div><span className='hotel_location'>Marine Drive, Mumbai</span><span>2 minutes walk to Nariman Point</span></div>
            <div><span></span><span className='hotel_cancel'>Free Cancellation</span></div>
            <div><p className='hotel_tag'>Breathtaking views of the Arabian Sea, relaxing pool area, well-equipped fitness center</p></div>
            </div>
        </div>
        <div className='container_item  textright'>
            
            <div className='width'><span className='hotel_reviewtype'>Excellent</span></div>
            <div><span className='hotel_ratings'>5903 Ratings</span></div>
            <div><p className='hotel_price'>₹ 14,250</p></div>
            <div><p className='Hotel_taxes'>+ ₹ 2,565 taxes & fees</p></div>
            <div><span className='hotel_login'>Login to Book Now & Pay Later!</span></div>
          
       </div></div></div>
    </div>
</div>
    )}
export default Hotel
