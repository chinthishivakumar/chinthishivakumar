
import './App.css'
import Header from './components/header.jsx'
import Hotel from './components/hotelcard.jsx'
function App() {
  

  return (
    <> <Header></Header>
    <Hotel></Hotel>
    </>
  )
}

export default App
